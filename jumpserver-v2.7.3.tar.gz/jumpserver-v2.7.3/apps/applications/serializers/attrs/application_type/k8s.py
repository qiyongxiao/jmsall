from ..application_category import CloudSerializer


__all__ = ['K8SSerializer']


class K8SSerializer(CloudSerializer):
    pass
