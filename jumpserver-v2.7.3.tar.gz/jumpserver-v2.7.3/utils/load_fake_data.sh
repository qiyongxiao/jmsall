#!/bin/bash
#

python ../apps/manage.py loaddata fake
