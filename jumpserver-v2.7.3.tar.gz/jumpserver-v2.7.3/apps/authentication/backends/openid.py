"""
使用下面的工程，进行jumpserver 的 oidc 认证
https://github.com/BaiJiangJie/jumpserver-django-oidc-rp
"""